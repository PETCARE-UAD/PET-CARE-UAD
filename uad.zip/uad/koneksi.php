<?php 
Mysqli_connect("localhost","root","","kuliner");
?>